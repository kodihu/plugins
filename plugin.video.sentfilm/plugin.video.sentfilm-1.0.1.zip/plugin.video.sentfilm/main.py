# -*- coding: utf-8 -*-

'''
    SentFilm Add-on
    Copyright (C) 2026

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import os, sys, re, xbmc, xbmcgui, xbmcplugin, locale, base64, random, string, json
import urllib.parse
import resolveurl

from resources.lib.modules import client, control, cache
from resources.lib.modules.utils import py2_encode, py2_decode, safeopen

BASE_URL = "http://www.sentfilm.hu"
HANDLE = int(sys.argv[1])

class SentFilm:
    def __init__(self):
        self.base_path = control.dataPath
        self.searchFileName = os.path.join(self.base_path, "search.history")

        self.user_agent = client.randomagent()

        try:
            locale.setlocale(locale.LC_ALL, "hu_HU.UTF-8")
        except:
            pass

    def get_html(self, url, post=None):
        headers = {'User-Agent': self.user_agent}
        return client.request(url, post=post, headers=headers, timeout='30')

    def main_menu(self):
        categories = [
            ("Szinkronizált keresztény filmek", f"{BASE_URL}/filmek/szinkronizalt"),
            ("Feliratos keresztény filmek", f"{BASE_URL}/filmek/feliratos"),
            ("Bibliai gyerekfilmek", f"{BASE_URL}/filmek/gyerekfilmek"),
            ("Sorsfordító", f"{BASE_URL}/filmek/sorsfordito"),
            ("Dokumentum, riport", f"{BASE_URL}/filmek/dokumentumfilm"),
            ("Rövidfilmek", f"{BASE_URL}/filmek/rovidfilmek"),
            ("Keresztény zene", f"{BASE_URL}/filmek/zene"),
            ("Családi filmek", f"{BASE_URL}/filmek/csaladi_filmek")
        ]

        for title, url in categories:
            li = control.item(label=title)
            query = urllib.parse.urlencode({'action': 'list_movies', 'url': url})
            control.addItem(HANDLE, f"{sys.argv[0]}?{query}", li, True)

        li = control.item(label="Keresés")
        li.setArt({'icon': 'DefaultFolder.png'})
        query = urllib.parse.urlencode({'action': 'search_menu'})
        control.addItem(HANDLE, f"{sys.argv[0]}?{query}", li, True)

        control.directory(HANDLE)

    def search_menu(self):
        li = control.item(label='[COLOR lightgreen]Új keresés[/COLOR]')
        query = urllib.parse.urlencode({'action': 'do_search'})
        control.addItem(HANDLE, f"{sys.argv[0]}?{query}", li, True)

        if os.path.exists(self.searchFileName):
            try:
                with open(self.searchFileName, "r") as f:
                    olditems = f.read().splitlines()
                
                items = list(set(olditems))
                items.sort(key=locale.strxfrm)

                for item in items:
                    if item.strip():
                        li = control.item(label=item)
                        query = urllib.parse.urlencode({'action': 'list_search', 'keyword': item})
                        control.addItem(HANDLE, f"{sys.argv[0]}?{query}", li, True)
                
                if items:
                    li = control.item(label='[COLOR red]Keresési előzmények törlése[/COLOR]')
                    query = urllib.parse.urlencode({'action': 'delete_history'})
                    control.addItem(HANDLE, f"{sys.argv[0]}?{query}", li, False)
            except:
                pass

        control.directory(HANDLE)

    def do_search(self):
        kb = control.keyboard('', 'Keresés')
        kb.doModal()
        if kb.isConfirmed():
            keyword = kb.getText()
            if len(keyword) >= 3:
                if not os.path.exists(self.base_path):
                    os.makedirs(self.base_path)
                with open(self.searchFileName, "a") as f:
                    f.write(f"{keyword}\n")
                
                self.list_search_results(keyword)
            else:
                control.infoDialog('Túl rövid a keresendő kifejezés!', 'Hiba')

    def delete_history(self):
        if os.path.exists(self.searchFileName):
            os.remove(self.searchFileName)
        control.refresh()

    def list_search_results(self, keyword):
        control.content(HANDLE, 'movies')
        search_url = f"{BASE_URL}/kereses"
        post_data = f"keyword={urllib.parse.quote_plus(keyword)}"
        
        html = cache.get(self.get_html, 1, search_url, post_data)
        
        pattern = r'search-item.*?src="([^"]+)".*?<h3><a href="([^"]+)">([^<]+)</a>'
        matches = re.findall(pattern, html, re.DOTALL)
        
        if not matches:
            control.dialog.ok("Keresés", f"Nincs találat: '{keyword}'")
            return

        for thumb, link, title in matches:
            self._add_movie_item(title, link, thumb)
        
        control.directory(HANDLE)

    def list_movies(self, category_url):
        control.content(HANDLE, 'movies')
        html = cache.get(self.get_html, 2, category_url)
        
        pattern = r'post-details.*?src="([^"]+)".*?<h3><a href="([^"]+)">([^<]+)</a>'
        matches = re.findall(pattern, html, re.DOTALL)
        
        if not matches:
            pattern = r'post-details">.*?src="([^"]+)".*?href="([^"]+)" class="inner-image-overlay".*?<h3>([^<]+)</h3>'
            matches = re.findall(pattern, html, re.DOTALL)

        for thumb, link, title in matches:
            self._add_movie_item(title, link, thumb)

        pagination = re.findall(r'<li><a href="([^"]+)">(&raquo;|Következő)</a></li>', html)
        if pagination:
            li = control.item(label="[COLOR yellow][I]Következő oldal >>>[/I][/COLOR]")
            query = urllib.parse.urlencode({'action': 'list_movies', 'url': pagination[0][0]})
            control.addItem(HANDLE, f"{sys.argv[0]}?{query}", li, True)
        
        control.directory(HANDLE)

    def _add_movie_item(self, title, link, thumb):
        if not thumb.startswith('http'):
            thumb = BASE_URL + thumb.replace('./', '/')

        li = control.item(label=title.strip())
        li.setInfo('video', {'title': title.strip()})
        li.setArt({'thumb': thumb, 'poster': thumb, 'icon': thumb})
        li.setProperty('IsPlayable', 'true')
        
        query = urllib.parse.urlencode({'action': 'play', 'url': link})
        control.addItem(HANDLE, f"{sys.argv[0]}?{query}", li, False)

    def play_video(self, page_url):
        html = self.get_html(page_url)
        
        plot_match = re.search(r'<div class="post-content">(.*?)</div>', html, re.DOTALL)
        plot = ""
        if plot_match:
            plot = re.sub('<.*?>', '', plot_match.group(1)).strip()

        sources = []
        iframes = re.findall(r'<iframe.*?src=["\']([^"\']+)["\']', html)
        for url in iframes:
            url = url.replace('&amp;', '&')
            if "player.html" in url or url.startswith('./'): continue
            if url.startswith('//'): url = 'https:' + url
            
            name = "Lejátszás"
            if "youtube" in url or "youtu.be" in url: name = "YouTube"
            elif "gloria.tv" in url: name = "Gloria.tv"
            elif "arclight.org" in url: name = "Arclight"
            sources.append({'name': name, 'url': url})

        if not sources:
            control.infoDialog('Nem található videó.', 'Hiba')
            return

        target_url = sources[0]['url']
        if len(sources) > 1:
            labels = [s['name'] for s in sources]
            selected = control.selectDialog(labels, "Válassz forrást")
            if selected == -1: return
            target_url = sources[selected]['url']

        playable_url = None

        try:
            playable_url = resolveurl.resolve(target_url)
        except:
            playable_url = None

        if not playable_url:
            source_html = self.get_html(target_url)

            video_match = re.search(r'["\'](https?:[^\s"\'<>]+?\.(?:m3u8|mp4)[^\s"\'<>]*?)["\']', source_html)
            if video_match:
                playable_url = video_match.group(1).replace('\\/', '/')
                if '.m3u8' in playable_url:
                    playable_url += '|User-Agent=' + urllib.parse.quote(self.user_agent)

        if not playable_url and ("youtube" in target_url or "youtu.be" in target_url):
            playable_url = target_url

        if playable_url:
            li = control.item(path=playable_url)
            li.setInfo('video', {'title': control.infoLabel('ListItem.Label'), 'plot': plot})

            if '.m3u8' in playable_url:
                li.setProperty('inputstream', 'inputstream.adaptive')
                li.setProperty('inputstream.adaptive.manifest_type', 'hls')
                li.setProperty('inputstream.adaptive.stream_headers', 'User-Agent=' + self.user_agent)
                
            control.resolve(HANDLE, True, li)
        else:
            control.infoDialog('A videó nem indítható el.', 'Hiba')

plugin = SentFilm()
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
action = params.get('action')

if not action:
    plugin.main_menu()
elif action == 'search_menu':
    plugin.search_menu()
elif action == 'do_search':
    plugin.do_search()
elif action == 'list_search':
    plugin.list_search_results(params.get('keyword'))
elif action == 'delete_history':
    plugin.delete_history()
elif action == 'list_movies':
    plugin.list_movies(params.get('url'))
elif action == 'play':
    plugin.play_video(params.get('url'))